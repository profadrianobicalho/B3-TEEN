# B3 Teen – banco de dados no GitHub

Estrutura
- `index.html` – o aplicativo (hospedar no GitHub Pages)
- `data/prices.json` – cotações (atualizadas pelo GitHub Actions)
- `data/groups/*.json` – um arquivo por grupo (gravado pelo Worker)
- `worker/` – Cloudflare Worker (guarda o token do GitHub)

Passo a passo
1. Crie o repositório **privado** `b3-teen-data` e envie estes arquivos.
2. Crie uma conta em brapi.dev, gere um token e salve em
   Settings → Secrets and variables → Actions → `BRAPI_TOKEN`.
3. Aba Actions → "Atualizar cotações B3" → Run workflow (teste). Confira `data/prices.json`.
4. Crie um token do GitHub (Settings → Developer settings → Fine-grained tokens)
   só para este repositório, permissão **Contents: Read and write**.
5. Em `worker/`: edite `wrangler.toml` (GH_REPO e ALLOWED_ORIGIN), depois
   `npx wrangler secret put GH_TOKEN` e `npx wrangler deploy`. Copie a URL gerada.
6. No `index.html`, cole a URL em `CONFIG.API_URL`.
7. Hospede o `index.html` (Pages exige repositório público: use um segundo repositório
   só com o index.html, ou o Cloudflare Pages). Coloque o endereço em ALLOWED_ORIGIN.

Privacidade: peça aos alunos para usar apelidos ou só o primeiro nome.

/* Cloudflare Worker: única porta de acesso ao repositório (o token nunca vai para o navegador).
   GET  /prices  → cotações        GET /ranking → ranking calculado no servidor
   POST /group   → salva o grupo (exige a chave secreta criada no aparelho do grupo) */
const TICKERS = ["PETR4","VALE3","ITUB4","BBDC4","MGLU3","WEGE3","BBAS3","RENT3"];
const START = 10000;
const enc = new TextEncoder(), dec = new TextDecoder();

const b64e = s => { let b = ""; for (const x of enc.encode(s)) b += String.fromCharCode(x); return btoa(b); };
const b64d = s => dec.decode(Uint8Array.from(atob(s.replace(/\n/g, "")), c => c.charCodeAt(0)));
const sha = async s => [...new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s)))].map(b => b.toString(16).padStart(2, "0")).join("");

const gh = (env, path, init = {}) => fetch(`https://api.github.com/repos/${env.GH_REPO}/contents/${path}`, {
  ...init, headers: { Authorization: `Bearer ${env.GH_TOKEN}`, "User-Agent": "b3-teen", Accept: "application/vnd.github+json", ...(init.headers || {}) } });
async function readJSON(env, path) {
  const r = await gh(env, path); if (!r.ok) return null;
  const j = await r.json(); return { sha: j.sha, data: JSON.parse(b64d(j.content)) };
}
const num = (v, max) => (typeof v === "number" && isFinite(v) && v >= 0 && v <= max) ? v : null;
const txt = (v, max) => (typeof v === "string") ? v.replace(/[<>]/g, "").trim().slice(0, max) : "";

function worth(g, quotes) {
  let t = g.cash;
  for (const [k, p] of Object.entries(g.pf || {})) if (quotes[k]) t += p.n * quotes[k].price;
  return t;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const cors = { "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN, "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Methods": "GET,POST,OPTIONS" };
    const json = (o, s = 200, extra = {}) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json", ...cors, ...extra } });
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

    try {
      const prices = (await readJSON(env, "data/prices.json"))?.data;
      if (!prices) return json({ error: "sem preços" }, 503);

      if (url.pathname === "/prices" && req.method === "GET")
        return json(prices, 200, { "Cache-Control": "public, max-age=300" });

      if (url.pathname === "/ranking" && req.method === "GET") {
        const cache = caches.default, key = new Request(url.toString());
        const hit = await cache.match(key); if (hit) return new Response(hit.body, { headers: { ...Object.fromEntries(hit.headers), ...cors } });
        const dir = await gh(env, "data/groups"); const files = dir.ok ? (await dir.json()).filter(f => f.name.endsWith(".json")) : [];
        const groups = (await Promise.all(files.slice(0, 200).map(f => readJSON(env, f.path)))).filter(Boolean).map(x => x.data);
        const out = groups.map(g => { const v = worth(g, prices.quotes);
          return { id: g.id, n: g.name, m: (g.mem || []).join(", "), v, w: (v / (g.weekStart || START) - 1) * 100 }; });
        const res = json(out, 200, { "Cache-Control": "public, max-age=60" });
        await cache.put(key, res.clone()); return res;
      }

      if (url.pathname === "/group" && req.method === "POST") {
        const b = await req.json(), g = b.group || {};
        if (!/^g[a-z0-9]{6,24}$/.test(b.id || "") || typeof b.key !== "string" || b.key.length < 16 || b.key.length > 80) return json({ error: "id/chave inválidos" }, 400);
        const mem = Array.isArray(g.mem) ? g.mem.map(m => txt(m, 30)).filter(Boolean) : [];
        const name = txt(g.name, 40), cash = num(g.cash, 1e6);
        if (!name || mem.length < 2 || mem.length > 6 || cash === null) return json({ error: "dados inválidos" }, 400);
        const pf = {};
        for (const [k, p] of Object.entries(g.pf || {})) {
          if (!TICKERS.includes(k) || !Number.isInteger(p.n) || p.n < 0 || num(p.avg, 1e6) === null) return json({ error: "carteira inválida" }, 400);
          if (p.n > 0) pf[k] = { n: p.n, avg: p.avg };
        }
        const rec = { id: b.id, name, mem, cash, pf, tx: (g.tx || []).slice(-200), hist: (g.hist || []).slice(-400).map(x => num(x, 1e6) ?? 0),
          weekStart: num(g.weekStart, 1e6) ?? START, day: g.day | 0, lastDate: txt(g.lastDate, 10), week: txt(g.week, 10), updated: new Date().toISOString() };
        if (worth(rec, prices.quotes) > START * 10) return json({ error: "patrimônio suspeito" }, 400);

        const path = `data/groups/${b.id}.json`, keyHash = await sha(b.key + b.id), old = await readJSON(env, path);
        if (old && old.data.keyHash !== keyHash) return json({ error: "este grupo pertence a outro aparelho" }, 403);
        const put = await gh(env, path, { method: "PUT", body: JSON.stringify({
          message: `salvar ${name}`, content: b64e(JSON.stringify({ ...rec, keyHash }, null, 1)), ...(old ? { sha: old.sha } : {}) }) });
        return put.ok ? json({ ok: true }) : json({ error: "falha ao gravar" }, put.status === 409 ? 409 : 502);
      }
      return json({ error: "rota inexistente" }, 404);
    } catch (e) { return json({ error: "erro interno" }, 500); }
  }
};

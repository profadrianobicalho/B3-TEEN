"""Busca cotações da B3 (brapi.dev) e grava data/prices.json."""
import json, os, urllib.request, datetime

TICKERS = ["PETR4","VALE3","ITUB4","BBDC4","MGLU3","WEGE3","BBAS3","RENT3"]
TOKEN = os.environ["BRAPI_TOKEN"]
PATH = "data/prices.json"

try:
    old = json.load(open(PATH))["quotes"]
except Exception:
    old = {}

quotes = dict(old)
for t in TICKERS:
    try:
        url = f"https://brapi.dev/api/quote/{t}?token={TOKEN}"
        with urllib.request.urlopen(url, timeout=20) as r:
            d = json.load(r)["results"][0]
        quotes[t] = {"price": round(d["regularMarketPrice"], 2),
                     "prev": round(d["regularMarketPreviousClose"], 2)}
    except Exception as e:
        print(f"Falha em {t}: {e} (mantendo valor anterior)")

out = {"updated": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
       "quotes": quotes}
json.dump(out, open(PATH, "w"), indent=1)
print("prices.json atualizado")
